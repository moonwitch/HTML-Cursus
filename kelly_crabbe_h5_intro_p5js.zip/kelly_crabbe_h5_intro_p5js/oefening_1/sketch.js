function setup() {
  createCanvas(600, 400);
 
  // background(255,255,255);
}

function draw() {
  noStroke();
  
  fill(9,20,99);
  rect(0,0,200,height)
  
  fill(255,255,255);
  rect(200,0,200,height)
  
  fill(200,0,0);
  rect(400,0,200,height)

}
