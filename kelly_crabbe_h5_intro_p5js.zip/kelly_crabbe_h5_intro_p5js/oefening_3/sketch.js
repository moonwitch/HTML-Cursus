function setup() {
  createCanvas(600, 400);
 
  background(255,255,255);
}

function draw() {
  noStroke();
  
  fill(230,0,0);
  
  circle(width/2,height/2,height/2);

}
